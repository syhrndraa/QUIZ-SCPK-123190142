function varargout = Mining_123190142_Quiz_3_SyahrindraDzakyRamadhan(varargin)
% MINING_123190142_QUIZ_3_SYAHRINDRADZAKYRAMADHAN MATLAB code for Mining_123190142_Quiz_3_SyahrindraDzakyRamadhan.fig
%      MINING_123190142_QUIZ_3_SYAHRINDRADZAKYRAMADHAN, by itself, creates a new MINING_123190142_QUIZ_3_SYAHRINDRADZAKYRAMADHAN or raises the existing
%      singleton*.
%
%      H = MINING_123190142_QUIZ_3_SYAHRINDRADZAKYRAMADHAN returns the handle to a new MINING_123190142_QUIZ_3_SYAHRINDRADZAKYRAMADHAN or the handle to
%      the existing singleton*.
%
%      MINING_123190142_QUIZ_3_SYAHRINDRADZAKYRAMADHAN('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in MINING_123190142_QUIZ_3_SYAHRINDRADZAKYRAMADHAN.M with the given input arguments.
%
%      MINING_123190142_QUIZ_3_SYAHRINDRADZAKYRAMADHAN('Property','Value',...) creates a new MINING_123190142_QUIZ_3_SYAHRINDRADZAKYRAMADHAN or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before Mining_123190142_Quiz_3_SyahrindraDzakyRamadhan_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to Mining_123190142_Quiz_3_SyahrindraDzakyRamadhan_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help Mining_123190142_Quiz_3_SyahrindraDzakyRamadhan

% Last Modified by GUIDE v2.5 23-Apr-2021 19:47:48

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @Mining_123190142_Quiz_3_SyahrindraDzakyRamadhan_OpeningFcn, ...
                   'gui_OutputFcn',  @Mining_123190142_Quiz_3_SyahrindraDzakyRamadhan_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before Mining_123190142_Quiz_3_SyahrindraDzakyRamadhan is made visible.
function Mining_123190142_Quiz_3_SyahrindraDzakyRamadhan_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to Mining_123190142_Quiz_3_SyahrindraDzakyRamadhan (see VARARGIN)

% Choose default command line output for Mining_123190142_Quiz_3_SyahrindraDzakyRamadhan
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes Mining_123190142_Quiz_3_SyahrindraDzakyRamadhan wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = Mining_123190142_Quiz_3_SyahrindraDzakyRamadhan_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in pushbutton4.
function pushbutton4_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
opts = detectImportOptions('glass.csv');
opts.SelectedVariableNames = (1:10);
data = readmatrix('glass.csv',opts);
set(handles.uitable1,'data',data);

% --- Executes on button press in pushbutton5.
function pushbutton5_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(handles.uitable1,'data','');



function RI_Callback(hObject, eventdata, handles)
% hObject    handle to RI (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of RI as text
%        str2double(get(hObject,'String')) returns contents of RI as a double


% --- Executes during object creation, after setting all properties.
function RI_CreateFcn(hObject, eventdata, handles)
% hObject    handle to RI (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function Na_Callback(hObject, eventdata, handles)
% hObject    handle to Na (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Na as text
%        str2double(get(hObject,'String')) returns contents of Na as a double


% --- Executes during object creation, after setting all properties.
function Na_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Na (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function Mg_Callback(hObject, eventdata, handles)
% hObject    handle to Mg (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Mg as text
%        str2double(get(hObject,'String')) returns contents of Mg as a double


% --- Executes during object creation, after setting all properties.
function Mg_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Mg (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function Al_Callback(hObject, eventdata, handles)
% hObject    handle to Al (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Al as text
%        str2double(get(hObject,'String')) returns contents of Al as a double


% --- Executes during object creation, after setting all properties.
function Al_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Al (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function Si_Callback(hObject, eventdata, handles)
% hObject    handle to Si (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Si as text
%        str2double(get(hObject,'String')) returns contents of Si as a double


% --- Executes during object creation, after setting all properties.
function Si_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Si (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function K_Callback(hObject, eventdata, handles)
% hObject    handle to K (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of K as text
%        str2double(get(hObject,'String')) returns contents of K as a double


% --- Executes during object creation, after setting all properties.
function K_CreateFcn(hObject, eventdata, handles)
% hObject    handle to K (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function Ca_Callback(hObject, eventdata, handles)
% hObject    handle to Ca (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Ca as text
%        str2double(get(hObject,'String')) returns contents of Ca as a double


% --- Executes during object creation, after setting all properties.
function Ca_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Ca (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function Ba_Callback(hObject, eventdata, handles)
% hObject    handle to Ba (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Ba as text
%        str2double(get(hObject,'String')) returns contents of Ba as a double


% --- Executes during object creation, after setting all properties.
function Ba_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Ba (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function Fe_Callback(hObject, eventdata, handles)
% hObject    handle to Fe (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Fe as text
%        str2double(get(hObject,'String')) returns contents of Fe as a double


% --- Executes during object creation, after setting all properties.
function Fe_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Fe (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton1.
function pushbutton1_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
RI = str2double(get(handles.RI,'String'));
Na = str2double(get(handles.Na,'String'));
Mg = str2double(get(handles.Mg,'String'));
Al = str2double(get(handles.Al,'String'));
Si = str2double(get(handles.Si,'String'));
K = str2double(get(handles.K,'String'));
Ca = str2double(get(handles.Ca,'String'));
Ba = str2double(get(handles.Ba,'String'));
Fe = str2double(get(handles.Fe,'String'));
klasifikasi = str2double(get(handles.klasifikasi,'String'));

sample = [RI Na Mg Al Si K Ca Ba Fe];

opts = detectImportOptions('glass.csv');
opts.SelectedVariableNames = (1:9);
training = readmatrix('glass',opts);

opts = detectImportOptions('glass.csv');
opts.SelectedVariableNames = (10);
group = readmatrix('glass.csv',opts);

class = fitcknn(training,group, 'NumNeighbor',klasifikasi);

typeofglass = predict(class, sample);

set(handles.text14, 'String', typeofglass);

if typeofglass == 1
    set(handles.text13, 'String', 'building windows float processed');
elseif typeofglass == 2
    set(handles.text13, 'String', 'building windows nonfloat processed');
elseif typeofglass == 3
    set(handles.text13, 'String', 'vehicle windows float processed');
elseif typeofglass == 4
    set(handles.text13, 'String', 'vehicle windows nonfloat processed');
elseif typeofglass == 5
    set(handles.text13, 'String', 'containers');
elseif typeofglass == 6
    set(handles.text13, 'String', 'tableware');
elseif typeofglass == 7
    set(handles.text13, 'String', 'headlamps');
end;

% --- Executes on button press in pushbutton2.
function pushbutton2_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(handles.RI,'string','');
set(handles.Na,'string','');
set(handles.Mg,'string','');
set(handles.Al,'string','');
set(handles.Si,'string','');
set(handles.K,'string','');
set(handles.Ca,'string','');
set(handles.Ba,'string','');
set(handles.Fe,'string','');
set(handles.klasifikasi,'string','');
set(handles.text13,'string','');
set(handles.text14,'string','');


function klasifikasi_Callback(hObject, eventdata, handles)
% hObject    handle to klasifikasi (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of klasifikasi as text
%        str2double(get(hObject,'String')) returns contents of klasifikasi as a double


% --- Executes during object creation, after setting all properties.
function klasifikasi_CreateFcn(hObject, eventdata, handles)
% hObject    handle to klasifikasi (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
